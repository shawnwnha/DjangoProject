from __future__ import unicode_literals
from django.db import models
import bcrypt
import re
validate_email = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
####################################################################################################
class UsersManager(models.Manager):
	def register_validator(self, postData): 
		errors = {}
		name = postData['name']
		username = postData['username']
		password = postData['password']
		password_c = postData['password_c'] 
		if len(name) < 1 or len(username) < 1 or len(password) <1 or len(password_c)<1:
			errors['length'] = "All inputs must be filled"
			return errors 
		else:
			if len(name) < 4 or len(username) < 4:
				errors['name_length'] = "Name and UserName must be more than 3 characters"
			if not name.isalpha() or not username.isalpha():
				errors['name_type'] = "Name be alphabets only"
			if len(password) < 8 or len(password_c) < 8:
				errors['password_length'] = "Password be more than 8 characters"
			if password != password_c:
				errors['password_match'] = "Password confirmation failed"

			return errors		

	def login_validator(self, postData):
		errors ={}
		login_id = postData['login_id']
		login_password = postData['login_pw']
		
		if len(login_id)<1 or len(login_password)<1:
			errors['length'] = "All inputs must be filled"
			return errors
		else:
			user = Users.objects.filter(username = login_id)
			if not user:
				errors['invalid_id'] = "There is no record of this ID"
			else:
				user = Users.objects.get(username = login_id)
				data_password = user.password 
				if not bcrypt.checkpw(str(login_password).encode(), data_password.encode()):
					errors['invalid_password'] = "Invalid Password"
			return errors

class Users(models.Model):
	name = models.CharField(max_length=255)
	username = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add =True)
	objects = UsersManager()

class Trips(models.Model):
	destination= models.CharField(max_length=255)
	desc= models.CharField(max_length=255)
	datefrom = models.DateField()
	dateto = models.DateField()
	created_at = models.DateTimeField(auto_now_add =True)
	users = models.ManyToManyField(Users, related_name ="Users_Trips")
	admin = models.ForeignKey(Users, related_name ="Users_admin")