from __future__ import unicode_literals
from django.shortcuts import render, redirect 
from django.contrib import messages 
from .models import Users,Trips
import bcrypt 
from datetime import date

def loginpage(request):
	return render(request, 'exam/loginpage.html')

def register(request):
	errors = Users.objects.register_validator(request.POST)
	if len(errors):
		for tag, content in errors.iteritems():
			messages.error(request,content,extra_tags=tag)
		print"!"
		return redirect('/main')
	else:
		name = request.POST['name']
		username = request.POST['username']
		password = request.POST['password']
		hashed_pw = bcrypt.hashpw(str(password).encode(), bcrypt.gensalt())
		Users.objects.create(name=name, username =username, password=hashed_pw)
		messages.success(request, "you have successfully registered")
		return redirect('/main')

def login(request):
	errors = Users.objects.login_validator(request.POST)
	if len(errors):
		for tag, content in errors.iteritems():
			messages.error(request, content, extra_tags=tag)
		return redirect('/main')
	else:
		user = Users.objects.get(username = request.POST['login_id'])
		request.session['id'] = user.id ########### SAVE SESSION['ID'] ON LOGIN 
		return redirect('/travels')
######################################################################################################
def travelsadd(request):
	return render(request, 'exam/travelsadd.html')

def travelsgo(request):
	destination = request.POST['destination']
	description = request.POST['description']
	datefrom = request.POST['datefrom']
	dateto = request.POST['dateto']

	if len(destination) <1 or len(description) <1 or len(datefrom)<1 or len(dateto)<1:
		messages.error(request, "No field should be empty")
		return redirect('/travels/add')
	else:
		now = date.today()
		if str(datefrom) < str(now):
			messages.error(request, "Travel must be on the future date")
			return redirect('/travels/add')
		if str(datefrom) > str(dateto):
			messages.error(request, "Date From must be before Date To")
			return redirect('/travels/add')
		else:
			user = Users.objects.get(id=request.session['id'])
			trip= Trips.objects.create(destination=destination,desc=description,datefrom=datefrom,dateto=dateto, admin=user)
			newtrip = Trips.objects.get(id = trip.id)
			newtrip.users.add(user)
			print "@@@@@@@@@@@@@@@@@@@"
			return redirect('/travels')

###############################################################################################################
def travels(request):
	this_user = Users.objects.get(id = request.session['id']) # this user
	trips = Trips.objects.filter(users=this_user) # this users' trip
	othertrips = Trips.objects.exclude(users =this_user) # other users' trip 
	
	print request.session['id']
	print othertrips 
	context={
		'user': this_user,
		'trips': trips,
		'othertrips': othertrips,
	}
	return render(request, 'exam/travelspage.html', context)

###############################################################################################################
def travelshow(request,id):
	travel = Trips.objects.get(id=id) 
	planned_user = travel.admin
	other_user = travel.users.exclude(id=planned_user.id)
	context = {
		'travel': travel,
		'planned_user': planned_user,
		'other_user': other_user,

	}
	return render(request, 'exam/trip.html', context)
###############################################################################################################
def join(request,id):
	this_travel = Trips.objects.get(id=id)
	this_user = Users.objects.get(id=request.session['id'])
	this_travel.users.add(this_user)
	return redirect('/travels')


def logout(request):
	request.session['id'] = None
	return redirect('/main')
