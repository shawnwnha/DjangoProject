from django.conf.urls import url
from . import views

urlpatterns =[
	url(r'^main$', views.loginpage),
	url(r'^register$', views.register),
	url(r'^login$', views.login),
	url(r'^travels$', views.travels),
	url(r'^travels/add$', views.travelsadd),
	url(r'^travels/0$', views.travelsgo),
	url(r'^travels/destination/(?P<id>\d+)$',views.travelshow),
	url(r'^travels/join/(?P<id>\d+)$',views.join),
	url(r'^main/logout$', views.logout),
]